// -------------------------
// Inject Navigation Bar
// -------------------------
document.addEventListener("DOMContentLoaded", () => {
    const navbar = document.getElementById("navbar");

    if (navbar) {
        navbar.innerHTML = `
            <nav class="navbar">
                <a href="index.html">Home</a>
                <a href="about.html">About Us</a>
                <a href="product.html">Product</a>
                <a href="contact.html">Contact</a>
                <a href="enquiry.html">Enquiry</a>
            </nav>
        `;
    }
});

// -------------------------
// HOME PAGE – Modal Popup
// -------------------------
const promoBtn = document.getElementById("promoBtn");
const promoModal = document.getElementById("promoModal");
const closeBtn = document.querySelector(".close");

if (promoBtn && promoModal && closeBtn) {
    promoBtn.onclick = () => {
        promoModal.style.display = "block";
    };
    closeBtn.onclick = () => {
        promoModal.style.display = "none";
    };
    window.onclick = (e) => {
        if (e.target === promoModal) {
            promoModal.style.display = "none";
        }
    };
}

// -------------------------
// ABOUT PAGE – Accordion FAQ
// -------------------------
const accordions = document.getElementsByClassName("accordion");

if (accordions.length > 0) {
    for (let i = 0; i < accordions.length; i++) {
        accordions[i].addEventListener("click", function () {
            this.classList.toggle("active");
            const panel = this.nextElementSibling;

            panel.style.display = panel.style.display === "block" ? "none" : "block";
        });
    }
}

// -------------------------
// PRODUCT PAGE – Lightbox Gallery
// -------------------------
const images = document.querySelectorAll(".light-img");
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightbox-img");
const closeLightbox = document.getElementById("close-lightbox");

if (images.length > 0 && lightbox && lightboxImg && closeLightbox) {
    images.forEach((img) => {
        img.addEventListener("click", () => {
            lightbox.style.display = "flex";
            lightboxImg.src = img.src;
        });
    });

    closeLightbox.addEventListener("click", () => {
        lightbox.style.display = "none";
    });
}

// -------------------------
// PRODUCT PAGE – Search Filter
// -------------------------
const searchInput = document.getElementById("search");
const productList = document.getElementById("productList");

if (searchInput && productList) {
    searchInput.addEventListener("keyup", () => {
        const filter = searchInput.value.toLowerCase();
        const items = productList.getElementsByTagName("li");

        for (let i = 0; i < items.length; i++) {
            const text = items[i].textContent.toLowerCase();
            items[i].style.display = text.includes(filter) ? "" : "none";
        }
    });
}

// -------------------------
// PRODUCT PAGE – Load More Button
// -------------------------
const loadMoreBtn = document.getElementById("loadMore");
const productContainer = document.getElementById("productContainer");

if (loadMoreBtn && productContainer) {
    loadMoreBtn.addEventListener("click", () => {
        const newItem1 = document.createElement("p");
        newItem1.textContent = "Chocolate Donuts";

        const newItem2 = document.createElement("p");
        newItem2.textContent = "Vanilla Cupcakes";

        productContainer.appendChild(newItem1);
        productContainer.appendChild(newItem2);

        loadMoreBtn.style.display = "none";
    });
}

// -------------------------
// CONTACT PAGE – Enquiry Form Success Message
// -------------------------
const enquiryForm = document.getElementById("enquiryForm");
const successMsg = document.getElementById("successMsg");

if (enquiryForm && successMsg) {
    enquiryForm.addEventListener("submit", function (e) {
        e.preventDefault();
        successMsg.style.display = "block";
        enquiryForm.reset();
    });
}
