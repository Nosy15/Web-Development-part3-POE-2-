#Part 1
All the mistakes needed to be fixed in part 1 listed in Part 2

#Part 2
Changed menu.html file to product.html file
Added a README.md file in the Visual Studio Code
Remove the second index.html (homepage) file
Added enquiry.html file
Typed the correct link for the images to show up in the index, about and product website

#Part 3
Fixed mistakes with the tags and codes in every html file
Created a Javascript file called script.js and added codes
Added more codes in style.css
Added more codes in all html files
added navigation bars linked to Javascript
Added three more photos for the product.html
Ran all webpages and they function very well